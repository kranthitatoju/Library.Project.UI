import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { AuthorComponent } from './author/author.component';
import {AppService} from './author/app.service';
import { BooksComponent } from './books/books.component';
import { AllauthorsComponent } from './author/allauthors.component';
import { AddauthorComponent } from './author/addauthor.component';
import {FormsModule} from '@angular/forms';
import { FindauthorComponent } from './author/findauthor.component'

@NgModule({
  declarations: [
    AppComponent,
    AuthorComponent,
    BooksComponent,
    AllauthorsComponent,
    AddauthorComponent,
    FindauthorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([{path: 'authors', component: AuthorComponent,
    children:[
      {
       path : 'allauth',
       component: AllauthorsComponent},
       {
        path : 'addauth',
        component: AddauthorComponent},
      
        {
          path : 'findauthor',
          component: FindauthorComponent}]},
    {path: 'books', component: BooksComponent}])
  ], 
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
