export class Author{
    Id: Number;
    Name: String;
    Email: String;
    Phone: String;
   

}