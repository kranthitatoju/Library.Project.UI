import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';
import {Author} from './Author.Model';

@Component({
  selector: 'app-addauthor',
  templateUrl: './addauthor.component.html',
  styles: []
})
export class AddauthorComponent implements OnInit {
  private authorAdd : Author;
  constructor(private service:AppService) { }
  ngOnInit() { 
  }
  onSubmit(Value : Author){
    console.log("hi");
    this.service.AddAuthor(Value);
    alert("New Author "+Value.Name+" Added ");
  }
 
}