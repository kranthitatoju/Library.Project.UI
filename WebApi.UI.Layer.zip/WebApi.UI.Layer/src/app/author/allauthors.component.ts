import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';
import {Author} from './Author.Model';

@Component({
  selector: 'app-allauthors',
  templateUrl: './allauthors.component.html'
})
export class AllauthorsComponent implements OnInit {

  Authors : Author[];
  constructor(private service: AppService) { }
  ngOnInit() {
    this.GetAllAuthors()
  }
  GetAllAuthors(){
    this.service.GetAuthors().subscribe(authors => this.Authors = authors);
  }
  deleteauthor(id: number)
  {
    console.log(id+"this is the id clicked");
   // let id = 1113
    this.service.DeleteAuthor(id);
    this.GetAllAuthors();
    alert("Author Deleted");
  }
} 

