import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptions} from '@angular/http';
import { Author } from './Author.Model';
import {Observable,Subject} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
@Injectable()
export class AppService {
  private urlLink :string =  'http://localhost:54404/api/author';
  constructor(private http: Http) {}

  GetAuthors(){
    return this.http.get(this.urlLink).map((response : Response)=><Author[]>response.json());
  }

  private postResponse: any;
  private handleError : any;

  AddAuthor(AuthData:Author){
    try{
    let header = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: header });
    let body = JSON.stringify(AuthData);
    return this.http.post(this.urlLink,body,options).map((res: Response) => res.json()).subscribe((res:Author) => this.postResponse = res);
       }
    catch(error)
       {
      console.log(error);
       }
    finally{
      console.log(this.postResponse);
       }
  }

  DeleteAuthor(Id : number)
  {
    let header = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: header });
    console.log("indelete "+Id)
    return this.http.delete(this.urlLink+"/"+Id,options).map((res: Response) => res.json()).subscribe((res:Author) => this.postResponse = res);
  }

  findAuthor(name: string)
  {
    return this.http.get(this.urlLink+'/'+name).map((res:Response)=><Author>res.json())
  }
}
