import { Component, OnInit } from '@angular/core';
import { AppService} from './app.service';
import { AllauthorsComponent} from './allauthors.component';
//import { Author} from './Author.Model';

@Component({
  selector: 'Author-View',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.css']
})
export class AuthorComponent{
  constructor() { }
}

