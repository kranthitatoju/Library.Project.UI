import { Component, OnInit } from '@angular/core';
import { AppService} from './app.service';
import {Author} from './Author.Model';

@Component({
  selector: 'app-findauthor',
  template: `
    <div >
    <label>Enter Author Name</label>
    <input [(ngModel)]="localname">
    <button class="btn btn-primary" (click)=findauthor()   >find</button>
    </div>
    <div *ngIf="show">
    <ul id="authorul"class="list-group">
      <li class="list-group-item row " ><label class="col-md-4">Author Id:</label><strong class="col-md-6">{{this.localauthor.Id}}</strong></li>
      <li class="list-group-item row"><label class="col-md-4">Author Name:</label><strong class="col-md-6">{{this.localauthor.Name}}</strong></li>
      <li class="list-group-item row "><label class="col-md-4">Author Email:</label><strong class="col-md-8">{{this.localauthor.EmailAddress}}</strong></li>
      <li class="list-group-item row"><label class="col-md-4">Author Phone:</label><strong class="col-md-8">{{this.localauthor.Phone}}</strong></li>
    </ul>
    </div>
  `,
  styles: []
})
export class FindauthorComponent implements OnInit {
  localname : string = "";
  show = false;
  localauthor : Author = {"Id":null,"Name":"","Email":"","Phone":""};
  constructor(private service: AppService ) { }
  ngOnInit() {
  }
  findauthor()
  { this.show = !this.show;
    this.service.findAuthor(this.localname).subscribe(res => 
    {this.localauthor = res,console.log(this.localauthor)});
   
  }

 
}
