export interface Book{
    Id: Number;
    Name: String;
    AuthorId: Number;
    PublishDate: Date;
    ISBN : String;
}