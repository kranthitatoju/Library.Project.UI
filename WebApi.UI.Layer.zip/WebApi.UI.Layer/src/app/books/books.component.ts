import { Component, OnInit } from '@angular/core';
import { BooksService } from './books.service';
import {Book} from './BookModel';
@Component({
  selector: 'app-books',
  template: `
  <div>
  <button class="btn btn-primary" (click)="getBooks()">get all Books</button>
  <table *ngIf="bookshow" class="table">
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Author Id</th>
          <th>publication date</th>
          <th>ISBN</th>
        </tr>
      </thead>
      <tbody>
        <tr class="success" *ngFor="let value of _Books">
          <td>{{value.Id}}</td>
          <td>{{value.Name}}</td>
          <td>{{value.AuthorId}}</td>
          <td>{{value.PublishDate}}</td>
          <td>{{value.ISBN}}</td>
        </tr>
      </tbody>
  </table>
</div>
  `,
  providers:[BooksService]
})
export class BooksComponent implements OnInit {
  bookshow = false;
  _Books : Book[];
  constructor(private service :BooksService ) { }
  ngOnInit(){
  }
  getBooks(){
    this.bookshow = !this.bookshow;
    this.service.GetBooks().subscribe(books => this._Books = books);
  }
}