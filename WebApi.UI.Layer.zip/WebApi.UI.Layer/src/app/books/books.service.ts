import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs';
import { Book } from "./BookModel";
import 'rxjs/add/operator/map';

@Injectable()
export class BooksService {
  private urlLink :string =  'http://localhost:54404/api/book';
  constructor(private _http : Http) { }

  GetBooks(){
    return  this._http.get(this.urlLink).map((res : Response)=><Book[]>res.json());
  }


}


